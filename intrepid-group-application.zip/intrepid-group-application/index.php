<?php
     
use IntrepidGroup\SampleApplication\Repository\StaticBookRepository;
use IntrepidGroup\SampleApplication\Repository\SortByFieldExtension;
require_once __DIR__.'/vendor/autoload.php';

/*class SortByFieldExtension extends \Twig_Extension
{

    public function getName()
    {
        return 'sortbyfield';
    }

    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('sortbyfield', array($this, 'sortByFilter')),
        );
    }

    public function sortByFilter($collectionToSort, $sortField, $direction = "asc")
    {
        $iterator = $collectionToSort->getIterator();

        $iterator->uasort(function($a, $b) use ($sortField, $direction) {
            if ($a->{'get' . ucfirst($sortField)}() === $b->{'get' . ucfirst($sortField)}()) {
                return ($direction == "asc") ? 0 : 1;
            }
            if ($a->{'get' . ucfirst($sortField)}() > $b->{'get' . ucfirst($sortField)}()) {
                return ($direction == "desc") ? 0 : 1;
            }
            return -1;
        });

        return $iterator;
    }
}
*/
// Fetch the collection of books

        //echo "success";   
        
$bookRepository = new StaticBookRepository();
$books = $bookRepository->fetchAll();
// Render the homepage


        
$twig = new Twig_Environment(new Twig_Loader_Filesystem(__DIR__.'/src/templates'));
$twig->addExtension(new SortByFieldExtension());
$twig->display('homepage.twig', array('books' => $books));




        

