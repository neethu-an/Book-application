<?php
use IntrepidGroup\SampleApplication\Repository\StaticBookRepository;
include 'StaticBookRepository.php';

$no = $_POST['columnName'];
$sort=$_POST['sort'];

$bookRepository = new StaticBookRepository();

if($no==1){
$books = $bookRepository->orderTitle($sort);}
if($no==2){
$books = $bookRepository->orderAuthor($sort);}
if($no==3){
$books = $bookRepository->orderYear($sort);}

$html = '';
foreach ($books as $book) {
    $language=$book->getLanguage();
    if($language === 'English'){
    $title=$book->getTitle();
    $author=$book->getAuthor();
    $year=$book->getYear();
    $html .= "<tr>
                    <td>".$title."</td><td class='one'>".$author."</td><td>".$year."</td>
                </tr>";
    }
}

echo $html;

